//
//  DitoSDK.h
//  DitoSDK
//
//  Created by Willian Junior Peres De Pinho on 22/12/20.
//

#import <Foundation/Foundation.h>

//! Project version number for DitoSDK.
FOUNDATION_EXPORT double DitoSDKVersionNumber;

//! Project version string for DitoSDK.
FOUNDATION_EXPORT const unsigned char DitoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DitoSDK/PublicHeader.h>


